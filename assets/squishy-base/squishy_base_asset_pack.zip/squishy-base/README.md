<!-- This document explains how to regenerate, inspect, and integrate the modular squishy character asset. -->
# Squishy Base · 韩系硅胶人偶

这是一个由 Blender `bpy` 程序生成的基础资产包，不包含网页交互或 Rapier 实现。

## 文件

- `squishy_base.glb`：默认无眼镜角色，包含材质、同一套蒙皮骨骼、8 个 morph targets。
- `squishy_base.blend`：可编辑工程，含默认角色、隐藏的可选眼镜、灯光和相机。
- `generate_squishy.py`：完整生成脚本；仅依赖 Blender 自带 Python、`bpy`、`bmesh` 和 `mathutils`。
- `glasses_soft_square.glb`：可选软方框眼镜，共用基础角色的骨骼结构与绑定矩阵。
- `asset_contract.json`：部件名称、骨骼层级、坐标系、静止姿态矩阵、关节锚点和碰撞体初始拟合建议。
- `preview.png` / `front.png` / `back.png`：Blender 实际渲染。
- `morph_contact_sheet.png`：基础状态及 8 种形变的满权重检查图。
- `pose_check.png`：非对称骨骼姿态检查图。
- `inspect_squishy.py`：检查 Blender 拓扑并重建检查图。
- `validate_asset.mjs` / `validation_report.json`：用本项目 Three.js 加载器检查导出内容、绑定矩阵、全部 morph 和骨骼变换。
- `topology_report.json`：各部件非流形边与零面积面的检查结果。

## 重新生成

已实际运行的版本：Blender **5.2.1 LTS**。脚本使用 Blender 4.x/5.x 的 Principled 接口，其他版本需实测。

在项目根目录运行：

```sh
/Applications/Blender.app/Contents/MacOS/Blender --background \
  --python assets/squishy-base/generate_squishy.py
```

在其他系统，将 Blender 可执行文件路径换成 `blender`。不依赖本项目的前端代码。

自定义输出目录或只生成资产：

```sh
blender --background --python generate_squishy.py -- --output-dir /absolute/output/path --skip-render
```

也可以在 Blender 的 Scripting 工作区打开脚本并运行。**脚本会清空当前场景**，请在新工程运行；输出文件会覆盖同名资产。渲染灯光和地面不进入 GLB。

```sh
blender --background --python assets/squishy-base/inspect_squishy.py
node assets/squishy-base/validate_asset.mjs
```

检查脚本从自身目录读取已生成的 `.blend` / `.glb`。如果使用自定义输出目录，请将检查脚本一并复制到那里。

## 结构与建模

约 3.77 头身，默认 A pose，Z-up 建模，人物正面朝 -Y，人物自身左侧为 +X。glTF 导出为 Y-up、正面 +Z。所有角色 mesh 的 origin 都在脚下的角色原点，位置和旋转归零、scale 为 1；关节 pivot 由骨骼定义，不能把 skinned mesh 的 origin 移动到单独肢体中心。

作者单位为米，模型总高约 3.735 m，这是比例设计空间而非成年男性身高。若运行时希望人偶高 0.30 m，统一缩放整个人物根节点约 `0.30 / 3.735`，同时同比缩放碰撞体和关节锚点。不要只缩放某个蒙皮 mesh。

模型从参数化环线表面生成。身体、头部、头发、服装和鞋子在各自部件内执行体素融合、表面平滑和受控减面，再转移关节权重；衣物主表面使用统一材质，袖口等边饰使用独立几何，最后生成 shape keys。这样减少了相交壳体造成的接缝，GLB 使用已确定的低面数表面，不依赖运行时细分。

这是为实时玩偶准备的混合三角形/多边形拓扑，**不是电影面部动画用的全四边形拓扑**。部件内可以有封闭的独立连通域，例如左右鞋、装饰线、眉毛；不同可替换部件之间有必要的覆盖。极端关节角度仍需配合运行时角度限制检查衣物穿插。

## 模块化替换

| 对象 | slot | 说明 |
|---|---|---|
| Body | body | 衣服下的皮肤、脖子与四肢 |
| Head | head | 脸、耳朵、小鼻子 |
| Hair_Comma | hair | 圆润侧分短发 |
| Eyes | eyes | 眼白与深色眼睛，独立材质 |
| Eyebrows | eyebrows | 平直自然眉 |
| FaceDetails | face-details | 眼睑与中性嘴形 |
| Top_Hoodie | tops | 卫衣、帽子、袖口、口袋 |
| Hoodie_Trim | top-trims | 卫衣袖口、下摆、领口与口袋线，随卫衣一起替换 |
| Hoodie_Drawstrings | accessories | 可独立隐藏的抽绳 |
| Bottom_WidePants | bottoms | 宽松下装 |
| Socks | socks | 奶白袜子 |
| Shoes_Chunky | shoes | 厚底运动鞋 |
| Glasses_SoftSquare | glasses | 单独 GLB 的可选眼镜 |

多个材质会使 Three.js 将一个 Blender 对象加载为含若干 SkinnedMesh 的 Group；请按 `userData.slot` / 对象父组识别部件，并遍历其后代，不能假设一个部件必然只有一个 draw call。

眼镜默认不出现在 `squishy_base.glb` 中，因为 glTF 没有通用的默认隐藏语义。在 `.blend` 的 `OPTIONAL_VARIANTS` 集合中可取消隐藏，或在运行时按需加载 `glasses_soft_square.glb`。

所有部件的 `skeletonId` 都是 `squishy-humanoid-v1`。加载替换部件后，应将其 SkinnedMesh 重新绑定到**现有角色骨骼**并保留匹配的绑定矩阵，再丢弃变体自带的重复骨架；不能只把它挂到 Head 骨骼下面，否则会发生双重变换。

以后只需预先制作一组符合该契约的发型、眉毛、眼睛、头型和服装变体，用户创建角色时选择现有部件与材质即可，不必逐用户运行 Blender。本包提供一个基础外观和一款眼镜，不声称已经包含完整变体库。新增变体需要匹配相同 rest pose、权重和 morph 形变场。

## 骨架与后续 ragdoll

17 根骨骼：Root、Pelvis、Chest、Neck、Head，以及左右 UpperArm、LowerArm、Hand、UpperLeg、LowerLeg、Foot。Root 是整体变换节点，其余 16 根可用于身体驱动。没有 Blender rigid body、烘焙物理、约束动画或 IK 依赖。

权重按局部肢体和关节过渡生成，每个顶点最多 4 个非零权重并归一化。手、脚、头可独立控制。上臂、前臂、大腿、小腿有独立变形控制，袖子和裤子跟随相同骨架。

`asset_contract.json` 中的 capsule 半径和锚点仅为后续 Rapier 拟合的起点，未实现物理，也未验证摆动稳定性。应用需要：

1. 根据最终人物尺寸拟合 collider，并设置质量、关节角度限制和相邻碰撞过滤。
2. 把物理刚体的世界姿态转换为骨骼父空间的局部姿态，考虑 bind/rest 偏移。
3. 根据抓取部位施加运行时约束，驱动骨架；不能把刚体世界矩阵直接写进局部骨骼变换。

JSON 的 `headWeb` / `tailWeb` / `centerWeb` / `axisWeb` 是已转成 Web 坐标的角色空间值。`restMatrixBlender` 和 `jointAnchor*Local` 仍是 Blender 骨骼空间；后者不可当作 Rapier 刚体局部坐标直接使用。Web 应优先从 GLB 实际加载的 rest matrices 推导刚体局部锚点。

Blender/glTF 中骨骼名含 `.L`、`.R`；项目当前 Three.js GLTFLoader 会清理名称中的句点，例如 `UpperArm.L` 变成 `UpperArmL`。验证报告记录实际加载后的名称。业务映射应统一命名，不要混用两种格式。

## Morph targets

所有活跃部件具有同名、同顺序的目标：

- `Squash`：整体压矮、横向及前后鼓起。
- `Stretch`：整体拉长并收窄。
- `Flatten`：沿前后方向压扁。
- `HeadSquash`：局部压头并向侧面鼓起。
- `FacePullLeft` / `FacePullRight`：按人物自身左右拉扯脸部。
- `FaceStretch`：横向拉宽脸部。
- `FaceSquash`：压缩脸部纵向结构。

默认权重为 **0**；设计区间 **0–1**。每个目标都是相对于 Basis 的增量，GLB 同时导出位置与法线 morph。不要把八个目标同时设置为 1；多个目标叠加可能导致过度拉伸或交叉，建议初始交互限制在 0–0.7。

同步控制所有当前部件的同名目标，包括所有多材质子 mesh，否则脸形改变时五官、头发或眼镜可能脱离表面。不要只改 `Head`。

**整体形变只改变顶点，不移动骨骼关节。** `Squash` / `Stretch` / `Flatten` 会让几何偏离原来的碰撞体与骨骼位置。运行时需要重拟合 collider / anchor，或将整体形变展示与完整 ragdoll 分成不同交互状态。局部脸部形变更适合与现有骨架姿态叠加。这个资产不假装 shape keys 能自动解决软体物理。

## 材质与预览差异

皮肤：偏暖硅胶色，roughness 0.57、IOR 1.42，Blender subsurface weight 0.065，轻微散射；头发为高粗糙度软橡胶，衣物使用纯色 matte PBR，眼睛略有高光。没有贴图下载依赖。

**标准 glTF PBR 不保存 Blender Principled 的完整 subsurface 效果。** GLB 保留颜色、roughness 与标准材质，并在材质 extras 中保留 `surfaceClass` 和 Blender SSS 参数；网页直接加载可得到半哑光效果，不能保证与 Cycles 的轻微皮下散射完全一致。未来如需一致的逆光透感，需要 Web 材质扩展或专用 shader。本步骤没有实现此类网页代码。参考 [Blender glTF 导出说明](https://docs.blender.org/manual/en/latest/addons/import_export/scene_gltf2.html)。

`PALETTE` 使用 sRGB 色值，生成时转换为线性颜色。修改肤色、发色或服装配色优先改这里；运行时可直接改材质颜色，无需重新建模。

## 检查边界

验证覆盖 GLB 实际加载、17 骨骼、全部形变位置/法线、默认权重、有限数值、归一化蒙皮权重、静止绑定矩阵、每根骨骼的可见顶点影响，以及眼镜与默认人物骨架的一致性。Blender 拓扑检查覆盖非流形边与零面积面，渲染检查包含正背面、局部形变与关节姿态。

没有执行浏览器帧率基准、Rapier 碰撞测试或大规模变体穿搭测试。网页性能还取决于设备、阴影和同屏人物数；精确面数、文件体积及 draw primitive 数见 `validation_report.json`。

最终基础角色：33,780 个三角面，18 个材质绘制单元，GLB 约 3.23 MB；独立眼镜 2,512 个三角面。Khronos glTF Validator 对两个 GLB 均报告 0 errors、0 warnings，报告保存在 `*_gltf_validation.json`。

项目生产构建已通过 `npm run build -- --webpack`；默认 Turbopack 构建在此运行环境受本地端口权限限制，使用 webpack 完成相同的生产编译与 TypeScript 检查。未修改现有网页源代码。
